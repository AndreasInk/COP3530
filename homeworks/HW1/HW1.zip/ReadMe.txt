Move the folder named 'hw1' to under the 'src' folder
before you start. 'hw1' is the package name, so please
do not change the name in the files.