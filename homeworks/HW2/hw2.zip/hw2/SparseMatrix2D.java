/**
 * Delete this line and put your full name over here
 */

package hw2;

import java.util.*;
import java.io.*;

public class SparseMatrix2D extends AbstractSparseMatrix2D {

    // The constructor; we set up the pink and blue nodes first in this constructor
    // Then we read the file and create the gray nodes one by one.
    // Please do not touch this method
    protected SparseMatrix2D(String inputFileName) throws FileNotFoundException {

            Scanner fileInput = new Scanner(new File(inputFileName));

            sizeOfMatrix = Integer.parseInt( fileInput.nextLine() );

            rows = new MatrixNode[sizeOfMatrix];
            for (int pos = 0; pos < sizeOfMatrix; pos++)
                rows[pos] = new MatrixNode(pos, -1);

            cols = new MatrixNode[sizeOfMatrix];
            for (int pos = 0; pos < sizeOfMatrix; pos++)
                cols[pos] = new MatrixNode(-1, pos);

            while ( fileInput.hasNextLine() ) {
                String line = fileInput.nextLine();
                String[] integers = line.split(" ");
                setEntry(Integer.parseInt(integers[0]), Integer.parseInt(integers[1]), Integer.parseInt(integers[2]));
            }

            fileInput.close();

    }

    // Please do not touch this method
    public void writeTheFourTraversalsToFile(String fileName) throws IOException {
        FileWriter fileWriter = new FileWriter( fileName );

        fileWriter.write(printRowMajorLtoR());
        fileWriter.write(printRowMajorRtoL());
        fileWriter.write(printColMajorTtoB());
        fileWriter.write(printColMajorBtoT());

        fileWriter.close();
    }

    // Please do not touch this method; This method adds to matrices and sends the result to a file
    // Runs in O(n^3) time, where n is the size of the matrix
    public static void addMatricesCubic(SparseMatrix2D A, SparseMatrix2D B, String outputFile) throws IOException {
        if(A.sizeOfMatrix != B.sizeOfMatrix)
            throw new IllegalArgumentException("The input matrices must have a same size!");

        FileWriter output = new FileWriter(outputFile);
        output.write(A.sizeOfMatrix + "\n");

        // Runs in O(n^3) time
        for(int i = 0; i < A.sizeOfMatrix; i++)
            for(int j = 0; j < A. sizeOfMatrix; j++) {
                Integer Aij = A.getEntry(i, j); // takes O(n) time
                Integer Bij = B.getEntry(i, j); // takes O(n) time
                if(Aij == null)  Aij = 0;
                if(Bij == null)  Bij = 0;
                if( Aij + Bij != 0) output.write(i + " " + j + " " + (Aij + Bij) + "\n");
            }
        output.close();
    }

    // Complete this method; This method should run in O(n^2) time
    // Do not declare new arrays/ArrayLists or any other data structure inside this method!
    public static void addMatricesQuadratic(SparseMatrix2D A, SparseMatrix2D B, String outputFile) throws IOException {
        // Do not declare any kind of array or any other data structures inside this method.
        if(A.sizeOfMatrix != B.sizeOfMatrix)
            throw new IllegalArgumentException("The input matrices must have a same size!");

        FileWriter output = new FileWriter(outputFile);

        output.write(A.sizeOfMatrix + "\n");

        // complete 
		
        output.close();
    }


    // Complete this method; do not declare new arrays/ArrayLists or any other
    // data structure inside this method!
    private void setEntry(Integer i, Integer j, Integer entry) {
        if (i > sizeOfMatrix - 1 || j > sizeOfMatrix - 1)
            throw new IllegalArgumentException("At least one index is out of bound!");

        MatrixNode newNode = new MatrixNode(i, j, entry); // insert this node properly into the matrix

        // your code goes right after this...

    
    }
}
