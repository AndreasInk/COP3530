package hw4; // do not delete

public class City {
	private final String name, color;
	
	public City(String name, String color) {
		this.name = name;
		this.color = color;
	}
	
	public String getCityColor() { 	return color; }
	public String getCityName() { return name; }
	public String toString() { return "<" + name + "," + color + ">"; }
}
