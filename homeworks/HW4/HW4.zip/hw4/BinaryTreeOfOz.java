package hw4; // do not delete

import java.io.*;
import java.util.Iterator;

import stacksandqueues.*; //do not delete this; use stacks and queues from this package if you need to

public class BinaryTreeOfOz implements Iterable<String> {
	//-------------Modify accordingly------------------------//
	private static class Node {
		final private City info;
		private Node left, right;

		public Node(City info, Node left, Node right, Node parent) {
			this.info = info;
			this.left = left;
			this.right = right;
		}

		public String getCity() {
			return info.getCityName();
		}

		public String getInfo() {
			return info.toString();
		}

		public String toString() { return info.toString(); }
	}

	//------------------------------------
	Node root;
	private int size;
	//-------------------------------------

	public boolean isEmpty() {
		return size == 0;
	}

	// Method 1: constructs a binary tree by reading information from an input file
	public BinaryTreeOfOz(String inputFile) throws IOException {
		// You must use the File class with the Scanner class as shown in 1-JavaPrimer.pdf

	}


	// Method 2: counts the # of trichromatic groups in the tree
	public int countTriChromaticGroups() {
		return recursiveChromaticGroups(root);
	}

	private int recursiveChromaticGroups(Node n) {
			return 0; // dummy statement

	}

	// Method 3: returns the reverse elevator order traversal of the tree
	public String getReverseElevatorOrder() {
		StringBuilder str = new StringBuilder();

		// complete

		return str.toString();
	}

	// Method 4: computes the height of the tree
	public int computeHeight() {
		int height = 0;

		// complete

		return height;
	}

	// Method 5: returns the paths to the root
	public String printPathsBackToTheRoot() {
		StringBuilder str = new StringBuilder();

		// complete

		return str.toString();
	}

	// Method 6: finds out the first common city for two cities
	public String findFirstCommonCity(String cityA, String cityB) {
		String str = "";

		// complete

		return str;
	}


	// The 7th item; you need create an iterator for this class
	// When a for-each loop is used to traverse an object of this class,
	// at every iteration, a string representation of the current node can be obtained
	public Iterator iterator() {
		return new BinaryTreeOfOz.BinaryTreeOfOzIterator(this);
	}

	public static class BinaryTreeOfOzIterator implements Iterator<String> {
		public BinaryTreeOfOzIterator(BinaryTreeOfOz T)   {
		}

		public boolean hasNext()  {
			return false; // dummy statement
		}

		public String next() {
			return "";
		}
	}
}
