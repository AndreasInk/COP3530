package hw3;

import java.io.*;

public class TestExitFinder {

	// Do not touch this method.
	public static String squeeze(String s) {
		StringBuilder str = new StringBuilder();

		for(int i = 0; i < s.length(); i++)
			if( s.charAt(i) != ' ')
				str.append(s.charAt(i));

		return str.toString();
	}

	// Do not touch this method. It is checking if output is correct or not.
	public static boolean areSame(String f1, String f2) throws IOException {
		BufferedReader readerA = new BufferedReader(new FileReader(f1));
        BufferedReader readerB = new BufferedReader(new FileReader(f2));
        String line;
        StringBuilder fileAStuff = new StringBuilder(), fileBStuff = new StringBuilder();

        while( (line = readerA.readLine()) != null )
        	fileAStuff.append(squeeze(line));

        while( (line = readerB.readLine()) != null )
        	fileBStuff.append(squeeze(line));

        readerA.close(); readerB.close();
        return fileAStuff.toString().equals(fileBStuff.toString());
     }


	public static void main(String[] args) throws IOException {
		//...............................................................................//
		ExitFinder M = new ExitFinder("src/hw3/Mazes/HW3-maze1.txt");
		M.findExitPathStackBased();
		M.sendSolutionTo("src/hw3/Outputs/HW3-maze1-AO.txt");
		if(areSame("src/hw3/Outputs/HW3-maze1-AO.txt", "src/HW3/Outputs/HW3-maze1-EO.txt"))
			System.out.println("Great! Your code passed HW3-maze1.txt.");
		else
			System.out.println("Alert: Your code did not pass HW3-maze1.txt. Try again.");
		//...............................................................................//

		M = new ExitFinder("src/hw3/Mazes/HW3-maze2.txt");
		M.findExitPathStackBased();
		M.sendSolutionTo("src/hw3/Outputs/HW3-maze2-AO.txt");
		if(areSame("src/hw3/Outputs/HW3-maze2-AO.txt", "src/hw3/Outputs/HW3-maze2-EO.txt"))
			System.out.println("Great! Your code passed HW3-maze2.txt.");
		else
			System.out.println("Alert: Your code did not pass HW3-maze2.txt. Try again.");
		//...............................................................................//

		M = new ExitFinder("src/hw3/Mazes/HW3-maze3.txt");
		M.findExitPathStackBased();
		M.sendSolutionTo("src/hw3/Outputs/HW3-maze3-AO.txt");
		if(areSame("src/HW3/Outputs/HW3-maze3-AO.txt", "src/hw3/Outputs/HW3-maze3-EO.txt"))
			System.out.println("Great! Your code passed HW3-maze3.txt.");
		else
			System.out.println("Alert: Your code did not pass HW3-maze3.txt. Try again.");
		//...............................................................................//

		M = new ExitFinder("src/hw3/Mazes/HW3-maze4.txt");
		M.findExitPathStackBased();
		M.sendSolutionTo("src/hw3/Outputs/HW3-maze4-AO.txt");
		if(areSame("src/hw3/Outputs/HW3-maze4-AO.txt", "src/hw3/Outputs/HW3-maze4-EO.txt"))
			System.out.println("Great! Your code passed HW3-maze4.txt.");
		else
			System.out.println("Alert: Your code did not pass HW3-maze4.txt. Try again.");
		//...............................................................................//

		M = new ExitFinder("src/hw3/Mazes/HW3-maze5.txt");
		M.findExitPathStackBased();
		M.sendSolutionTo("src/hw3/Outputs/HW3-maze5-AO.txt");
		if(areSame("src/hw3/Outputs/HW3-maze5-AO.txt", "src/hw3/Outputs/HW3-maze5-EO.txt"))
			System.out.println("Great! Your code passed HW3-maze5.txt.");
		else
			System.out.println("Alert: Your code did not pass HW3-maze5.txt. Try again.");
		//...............................................................................//

		M = new ExitFinder("src/hw3/Mazes/HW3-maze6.txt");
		M.findExitPathStackBased();
		M.sendSolutionTo("src/hw3/Outputs/HW3-maze6-AO.txt");
		if(areSame("src/hw3/Outputs/HW3-maze6-AO.txt", "src/hw3/Outputs/HW3-maze6-EO.txt"))
			System.out.println("Great! Your code passed HW3-maze6.txt.");
		else
			System.out.println("Alert: Your code did not pass HW3-maze6.txt. Try again.");
		//...............................................................................//
	}
}
