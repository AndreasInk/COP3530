package hw3; // Do not delete this

import java.io.*; // Needed for file IO
import stacksandqueues.*; // Do not delete this

public class ExitFinder {
	int m,n; // initialize these two variables from the constructor
	boolean[][] visitMatrix; // use this from the findExitPathStackBased method for book-keeping; visitMatrix[x][y] = true if the cell
	                         // x,y is visited else it contains false

	char[][] environment, routeMatrix; // the environment matrix stores the input;
	// the routeMatrix is actually the solution matrix where
	// the visited cells are marked using dots

	Cell start, exit;  // initialize these two from the constructors

	boolean hasRun = false, pathExists = true; // hasRun is set to true when the solution is calculated
	// pathExists is set to false later when algorithm fails to find
	// a solution

	private static class Cell { // A nested class (do not touch this class)
		int i, j;
		public Cell(int i, int j) { this.i = i; this.j = j; }
		public boolean equals(Cell c) { return (c.i == i && c.j == j); } // compares 2 cells
	}

	// Do not touch this method.
	public ExitFinder(String mazeInputFile) throws IOException {

		FileReader input = new FileReader(mazeInputFile); // you must this to read the file
		BufferedReader mazeReader = new BufferedReader(input); // you must this to read the file
		String[] tokens = mazeReader.readLine().split(" ");
		m = Integer.parseInt(tokens[0]);
		n = Integer.parseInt(tokens[1]);
		environment = new char[m][n];
		routeMatrix = new char[m][n];
		visitMatrix = new boolean[m][n];

		for( int i = 0; i < m; i++) {
			tokens = mazeReader.readLine().split(" ");
			for( int j = 0; j < n; j++ ) {
				routeMatrix[i][j] = environment[i][j] = tokens[j].charAt(0);
				if( environment[i][j] == 'R' )
					start = new Cell(i,j);
				else if( environment[i][j] == 'E')
					exit  = new Cell(i,j);
			}
		}
		mazeReader.close();
		input.close();
	}

	// Please do not touch this method!	Use to check if the constructor has
	// read the file correctly or not.
	public String toString() {
		StringBuilder s = new StringBuilder();

		for( int i = 0; i < m; i++) {
			for( int j = 0; j < n; j++ )
				s.append(environment[i][j]).append(" ");
			s.append("\n");
		}
		return s.toString();
	}

	// Please do not touch this method!
	public void sendSolutionTo(String mazeSolution) throws IOException {
		File file = new File(mazeSolution);
		FileWriter mazeWriter = new FileWriter( file );

		if( !hasRun ) {
			mazeWriter.close();
			throw new IllegalStateException("Please run the findExitPath() method first!");
		}

		if( pathExists ) {
			for( int i = 0; i < m; i++) {
				for( int j = 0; j < n; j++ )
					mazeWriter.append(String.valueOf(routeMatrix[i][j])).append(" ");
				mazeWriter.append("\n");
			}
		}
		else
			mazeWriter.append("No path exists.");

		mazeWriter.close();
	}

	// Complete this method.
	public void findExitPathStackBased() {
		hasRun = true;
		LinkedStack<Cell> S = new LinkedStack<>();
		// complete the remaining part

	}
}
