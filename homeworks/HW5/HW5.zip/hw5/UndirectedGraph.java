package hw5; // do not delete

import java.io.*;
import java.util.*;

public class UndirectedGraph {
	//-------------------- Edge class (use this as a black box) ----------------------//
	// We are going to use adjacency map representation in this homework; see the slides.
	// Every neighbor list is stores using a TreeSet of Edge objects.
	// The whole graph is represented as an ArrayList(instead of a plain array) of TreeSets; one TreeSet for every vertex.
	// Note that the Edge objects need to contain just one vertex, the other one is not needed
	// since every edge in a TreeSet have a common vertex.
	private static class Edge implements Comparable<Edge> {
		private int vertex_id, weight;

		Edge(int vertex_id, int weight) {
			this.vertex_id = vertex_id;
			this.weight = weight;
		}

		public int getVertexID() {
			return vertex_id;
		}

		public int getWeight() {
			return weight;
		}

		public int compareTo(Edge e) {
			return this.getVertexID() - e.getVertexID();
		}

		public String toString() {
			return "<" + vertex_id + "," + weight + ">";
		}
	}
	//-------------------------------------------------------//

	//----------- Class variables, please be careful!------------//
	int n, m; // n: number of vertices; m: number of edges
	ArrayList<TreeSet<Edge>> vertices; // ArrayList is used for indexing and fast performance in practice
	//-----------------------------------------------------------//

	//Scans in data for an undirected graph from file
	public UndirectedGraph(String inputFile) throws IOException {
		// to make things simple, it is recommended to create a separate add edge helper method
		// that can insert an edge into the graph constructed so far
	}

	//Returns a string representation of graph
	public String toString() {
		return null; // dummy statement
	}

	//Returns the highest degree present in the graph
	//Degree being number of edges on a vertex
	public int degree() {
		return -1; // dummy statement
	}

	//Counts number of "triangles" present in graph
	public int countTriplets() {
		return -1; // dummy statement
	}

	//Returns Breadth First Traversal from initial vertex 0
	//If any vertex is left unvisited (is not a connected graph) returns null
	public String ifConnectedThenBreadthFirstTraversal() {
		return null; // dummy statement
	}

	//Returns the path resulting in the lowest weight between two vertices
	public int findShortestPathLengthBetween(int u, int v) {
		return -1; // dummy statement
	}

	//Checks if current graph is a Tree
	public boolean isTree() {
		return false; // dummy statement

	}
}