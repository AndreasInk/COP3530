package exam3;

import java.util.Iterator;

public class StudentBinaryTree implements Iterable<UnfStudent>{
    public static class Node {
        private UnfStudent studentInfo;
        private Node left, right, parent;

        public Node(int nNumber, String name, double gpa, Node parent) {
            studentInfo = new UnfStudent(nNumber, name, gpa);
            this.parent = parent;
        }

        public String toString() {
            return studentInfo.toString();
        }
    }

    private Node root = null;

    // inserts a new node using the path made up of 0s and 1s like we did in the class
    public void insert(int nNumber, String name, double gpa, String path) {
        // Complete; no two nodes can have the same UnfStudent
    }

    // returns the binary path for the node that contains 'nNumber'; return null if such a node is not present
    public String findPathEncodingOf(int nNumber){
        // Complete
        return ""; // dummy statement; delete when you are done
    }

    // returns the inorder traversal sequence, computed iteratively
    public String inOrderNonRecursive() { // hint: use a stack; feel free to use java.util.Stack
        // Complete
        return ""; // dummy statement; delete when you are done
    }

    // returns the inorder traversal sequence, computed recursively
    public String inOrderRecursive() { //
        // Complete
        return ""; // dummy statement; delete when you are done
    }

    // returns the binary path from the node that contains 'nNumber' to the root
    // return null if such a node is not present; hint: use the parent field
    public String constructPathFromNodeToRoot(int nNumber) {
        // Complete
        return ""; // dummy statement; delete when you are done
    }

    // checks if the tree is also a BST
    public boolean isBSTBasedOnnNumber() {
        // Complete
        return false; // dummy statement; delete when you are done
    }

    // checks if the tree is also a min-heap
    public boolean isHeapBasedOnnNumber() {
        // Complete
        return false; // dummy statement; delete when you are done
    }

    // counts the number of students whose gpa is > 'g'
    public int numberOfStudentsWhoseGPAisGreaterThan(double g) {
        // Complete
        return 0; // dummy statement; delete when you are done
    }

    // returns the name of the student whose nNumber is known
    public String findTheNameOf(int nNumber) {
        // Complete
        return ""; // dummy statement; delete when you are done
    }

    // returns the number of nodes having 2 children
    public int countNumberofNodesHaving2children() {
        // Complete
        return 0; // dummy statement; delete when you are done
    }

    // returns the number of leaves
    public int countNumberofLeaves() {
        // Complete
        return 0; // dummy statement; delete when you are done
    }

    // checks if this current tree is same as the given tree 'B'
    // 2 binary trees are same if their inorder travsersal sequence + preorder/postorder sequences are same
    public boolean isSame(StudentBinaryTree B){
        // Complete
        return false; // dummy statement; delete when you are done
    }

    // returns the nNumber stored in the inorder successor; null it does not exist
    public int inOrderSuccessorOf(int nNumber){
        // Complete
        return 0; // dummy statement; delete when you are done
    }

    // Complete the iterator for this class
    public Iterator iterator() {
        return new TreeIterator(this);
    }

    public static class TreeIterator implements Iterator<UnfStudent> {
        public TreeIterator(StudentBinaryTree T)   {
        }

        public boolean hasNext()  {
            return false; // dummy statement
        }

        public UnfStudent next() {
            return null; // dummy statement
        }
    }

}