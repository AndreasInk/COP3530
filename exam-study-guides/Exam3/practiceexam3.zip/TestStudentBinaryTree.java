package exam3;

public class TestStudentBinaryTree {
    public static void main(String[] args){
        // Create a few trees and try out the methods; no need to use files;
        // just use the insert() method to create a tree
        // See the slides and the binary tree HW for sample trees
    }
}
