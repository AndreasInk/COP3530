package exam3; // do not delete

public class UnfStudent {
	private int nNumber;
	private String name;
	private double gpa;
	
	public UnfStudent(int nNumber, String name, double gpa){
		this.nNumber = nNumber;
		this.name = name;
		this.gpa = gpa;
	}
	
	public int getnNumber() { return nNumber; }
	public void setnNumber(int n) { nNumber = n; }
	public String getName() { return name; }
	public void setName(String s) { name = s; }
	public double getGPA() { return gpa; }
	public void setGpa(double g) { gpa = g; }

	public String toString() {
		return "<" + nNumber + ", " + name + "> ";
	}
}
